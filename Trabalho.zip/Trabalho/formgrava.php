<?php   
      include("conecta.php");

      $recusername=$_GET["username"];
      $recemail=$_GET["email"];
      $recsenha=$_GET["senha"];

      mysqli_query($conexao, "insert into dados (username, email, senha) values ('$recusername', '$recemail', '$recsenha')");

      header ("location:lista.php");
      ?>