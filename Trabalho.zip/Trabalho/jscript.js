const form = document.getElementByld("form");
const username = document.getElementByld("username");
const email = document.getElementByld("email");
const senha = document.getElementByld("senha");
const confsenha = document.getElementByld("confsenha");

form.addEventLiatener("submit", (e) => {
    e.preventDefault();

    checkInputs();
});

function checkInputs(){
    const usernameValue = usarname.value;
    const emailValue = email.value;
    const senhaValue = senha.value;
    const confsenhaValue = confsenha.value;
    
    if (usernameValue === ""){
        setErrorFor(username, 'O nome de usuário é obrigatório!');
    } else {
        setSuccessFor(username);
    }

    if (emailValue === ""){
        setErrorFor(email, 'O email é obrigatório!');
    } else if (!checkEmail(emailValue)){
        setErrorFor(email, "Por favor, insira um email válido.");

     } else {
        setSuccessFor(email);
    }

    if (senhaValue === ""){
        setErrorFor(senha, 'A senha é obrigatório!');
    } else if (senhaValue.length < 7){
        setErrorFor(senha, 'A senha deve conter no mínimo 7 caracteres.');
    }else {
        setSuccessFor(senha);
    }

    if (confsenhaValue === ""){
        setErrorFor(confsenha, 'A a confirmação da senha é obrigatório!');
    } else if (confsenhaValue !== senhaValue){
        setErrorFor(confsenha, 'A senha deve ser a mesma.');
    }else {
        setSuccessFor(confsenha);
    }

    const formControl = form.querySelectorAll('form-control');

    const formIsValid = [...formControl].every((formControl) => {
        return formControl.className === "form-control sucess";

     });

     if (formIsValid) {
        console.log("O formulário está 100% válido");
     }
}

function setErrorFor(input, message) {
      const formControl = input.parentElement;
      const small = formControl.querySelector('small');

      small.innerText = messege;

      formControl.className = 'form-control error';
    }

function serSuccessFor(input) {
    const formControl = input.parentElement;
    
    formControl.className = "form-control success";
}

function checkEmail(email) {
    return /^[\w!#$%&’*+\/=?^`{|}~-]+(\.[\w!#$%&’*+\/=?^`{|}~-]+)*@(([\w- -]+\.)+[A-Za-z]{2,6}|\[\d{1,3} (\.\d{1,3}){3}\])$/ .test(
        email
      );
}
